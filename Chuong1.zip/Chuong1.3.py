#Nhap du lieu tu ban phim
name=input("Nhap ten cua ban: ")
print("Xin chao",name)
age=input("Nhap tuoi cua ban: ")
print("Tuoi cua ban la:",age)

#In du lieu ra man hinh
name="John"
age=25
height=1.75

print("Ten:",name)
print("Tuoi:",age)
print("Chieu cao:",height,"met")

