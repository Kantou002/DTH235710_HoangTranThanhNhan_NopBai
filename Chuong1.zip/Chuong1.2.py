import sys

#Lay cac tham so dong lenh
num1 = int(sys.argv[1])
num2 = int(sys.argv[2])

#Tinh tong 2 so
sum = num1 + num2

#In ket qua
print("Tong cua 2 so la: ", sum)