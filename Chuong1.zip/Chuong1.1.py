#Chuong Trinh tinh tong 2 so

#Nhap 2 so tu ban phim
a = int(input("Nhap so a: "))
b = int(input("Nhap so b: "))
#Tinh tong 2 so
tong = a + b
#In ket qua
print("Tong cua 2 so la: ", tong)






