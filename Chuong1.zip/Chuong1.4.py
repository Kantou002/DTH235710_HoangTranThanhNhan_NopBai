#mo dun
import math

number=16
sqrt=math.sqrt(number)

print("The square root of",number,"is",sqrt)