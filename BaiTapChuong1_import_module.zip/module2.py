#module2.py
question ='What is your quest?'
answer= 'To seek the holy grail'