import module1
import module2
print(module1.question)
print(module1.answer)
print(module2.question)
print(module2.answer)