#module1.py
question='What is the meaning of Life, The Universe, and Everything?'
answer=42